package com.example.safetourbcn;

public class DomainController {
}
